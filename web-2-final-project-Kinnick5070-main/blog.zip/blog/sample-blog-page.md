---
title: "This is just a sample blog post"
author: "John Doe"
description: "A nice description of this post"
published: "2024-3-1"
---
# One hash tag for an H1 affect

## This is an H2 (two hash tags)

### This is an H3 (3 hash tags)

# Use Ctrl+Shift+V to preview a markdown file in VSCode

this is **bold** text

This is a link [this is the link text](https://www.google.com)

### Here's a JavaScript code sample:
```js
if(this){

}
```
The above code is a JavaScript sample.

## Lists
### Ordered Lists
1. Item 1
1. Item 2
1. Item 3

### Unordered Lists
- Item 1
- Item 2
- Item 3

## Here's how you can put images in markdown:
![This is an eagle](/images/pickaxe.jpg)