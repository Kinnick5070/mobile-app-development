---
title: "This is another sample blog post"
author: "John Doe"
description: "A nice description of this post"
published: "2024-3-11"
---
# Another Sample Post

### Here's a JavaScript code sample:
```js
if(this){

}
```